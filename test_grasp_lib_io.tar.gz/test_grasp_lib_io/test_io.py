from grasp_lib import GraspMap
path_test_set='test_set'

# first set test indexing of a cut file
#slb=GraspMap(path_test_set+'/slb_lfi_30_28_x_10.cut',0)

def toCartMap(GM,completeAtRight=False) :
   import numpy as np
   nrows,ncols = GM['theta'].shape
   print nrows,ncols
   nrows_cart = (nrows-1)/2
   central_row=nrows_cart
   M={}
   for k in GM.M.keys() : M[k]=[]#np.zeros([nrows_cart,ncols)]
   for k in M.keys() : 
      offset = 0.
      scale = 1.
      if k == 'phi' : offset = 180.
      if k == 'theta' : scale = -1.
      for j in range(nrows_cart) :
         line = np.concatenate((GM.M[k][central_row+j],offset+scale*GM.M[k][central_row-j]))
         if completeAtRight :
            line = np.concatenate((line,GM.M[k][central_row+j][0]*np.ones([1])))
         M[k].append(offset+scale*line)
   for k in M.keys() : M[k]=np.array(M[k])
   return M
      


if True : ibs=GraspMap(path_test_set+'/ib_lfi_70_18_x_10.cut',0,closeColumn=False)
if False :
   ribs = ibs.copy()
   for k in ribs.M.keys() :
      if k!='phi' and k!='_row_values' and k!='_col_values' and k!='_row_index' and k!='_col_index' and k!='_line_index':
         print k
         ribs.M[k][:,-1]=ribs.M[k][:,0]
   ribs.M['phi'][:,-1]=ribs.M['phi'][:,0]*0+180

stop
#for nside in [65536/16,65536/8,65536/4] :
   #m=ibs.healpix(

